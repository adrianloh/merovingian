__copyright__ = 'Copyright (c) 2008 Jared Kuolt'

version = (0,5,1)
version_string = "Autumn ORM version %d.%d.%d" % version
