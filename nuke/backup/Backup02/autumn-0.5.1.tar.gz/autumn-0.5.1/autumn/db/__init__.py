def escape(string):
    return '`%s`' % string